package com.dongnaoedu.controller;

import com.dongnaoedu.service.IUserReg;
import com.dongnaoedu.vo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/10/25
 * 创建时间: 16:26
 */
@Controller
public class UserRegController {

    private static final String SUCCESS = "suc";
    private static final String FAILUER = "failure";

    @Autowired
    @Qualifier("para")
    private  IUserReg userReg;

    @RequestMapping("/userReg")
    public String userReg(){
        return "index";
    }

    @RequestMapping("/saveUser")
    @ResponseBody
    public String saveUser(@RequestParam("userName")String userName,
                           @RequestParam("email")String email,
                           @RequestParam("phoneNumber")String phoneNumber){
        try {
            if (userReg.userRegister(User.makeUser(userName,email,phoneNumber)))
                return SUCCESS;
            else
                return FAILUER;
        } catch (Exception e) {
            return FAILUER;
        }
    }


}
