package com.dongnaoedu.service;

import com.dongnaoedu.vo.User;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/10/25
 * 创建时间: 16:34
 * 用户注册接口
 */
public interface IUserReg {

    public boolean userRegister(User user);

}
