package com.dongnaoedu.service;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/10/26
 * 创建时间: 21:48
 */
public interface IProDepot {

    public void processDepot(String goodsId,int amount);

}
