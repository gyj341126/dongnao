package com.dongnaoedu.vo;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/11/07
 * 创建时间: 0:07
 */
public class GoodDepotStat {
    private String goodsId;
    private boolean isEmpty;

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean empty) {
        isEmpty = empty;
    }
}
