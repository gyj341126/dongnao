package com.dongnaoedu.rpc;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/10/26
 * 创建时间: 22:03
 */
public class RpcConst {

    public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";
    public static final String EXCEPTION = "exception";

}
