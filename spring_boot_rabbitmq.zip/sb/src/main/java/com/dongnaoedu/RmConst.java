package com.dongnaoedu;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/10/30
 * 创建时间: 11:53
 */
public class RmConst {

    public final static String QUEUE_HELLO = "sb.hello";
    public final static String QUEUE_USER = "sb.user";

    public final static String QUEUE_TOPIC_EMAIL = "sb.info.email";
    public final static String QUEUE_TOPIC_USER = "sb.info.user";
    public final static String RK_EMAIL = "sb.info.email";
    public final static String RK_USER = "sb.info.user";
    public final static String EXCHANGE_TOPIC = "sb.exchange";



}
