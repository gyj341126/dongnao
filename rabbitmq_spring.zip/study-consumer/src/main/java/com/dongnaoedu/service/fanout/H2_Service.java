package com.dongnaoedu.service.fanout;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;

/**
 * 动脑学院-Mark老师
 * 创建日期：2017/11/07
 * 创建时间: 20:59
 */
public class H2_Service implements MessageListener{
    private Logger logger = LoggerFactory.getLogger(H2_Service.class);
    public void onMessage(Message message) {
        logger.info("Get message:"+new String(message.getBody()));
    }
}
